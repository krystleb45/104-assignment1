//Object literal
var saloon={
    name:"The Fashion Pet",
    address:{
        state:"Baja California",
        city:"Tijuana",
        street:"Unversity 1234",
        zip:"12345"
    },
    hours:{
        opening:"9:00 am",
        closing:"9:00 pm"
    },
    pets:[
        {
            name:"Scooby",
            age:60,
            gender:"Male",
            breed:"Dane",
            service:"Grooming",
            owner:"Shaggy",
            phone:"555-555-5555"
        },
        {
            name:"Scrappy",
            age:50,
            gender:"Male",
            breed:"Mixed",
            service:"Nail cut",
            owner:"Shaggy",
            phone:"555-555-5555"
        },
        {
            name:"Koda",
            age:2,
            gender:"Male",
            breed:"Goldendoodle",
            service:"Grooming",
            owner:"Krystle",
            phone:"333-222-5555"
        }
    ]
}

//name,age,gender,breed,service,owner,phone
function displayInfo(){
    document.getElementById("info").innerHTML=`<h3> Welcome to ${saloon.name}</h3> <p> ${saloon.address.state}, ${saloon.address.city}, ${saloon.address.state}, ZIP: ${saloon.address.zip}</p>`;
}
displayInfo();

function displayPetInfo(){
    document.getElementById("petinfo").innerHTML=("you have" + saloon.pets.length + "pets");

}
displayPetInfo();

function displayPetName(){
for (let i=0; i < saloon.pets.length; i++){document.getElementById("petname").innerHTML+=`<p>${saloon.pets[i].name}</p>`;
}
}
displayPetName();

//for (let i = 0; i < saloon.pets.lenth; i++) {document.getElementById("petinfo").innerHTML;}